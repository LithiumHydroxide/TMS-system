<?php
session_start();
error_reporting(0);
include('includes/config.php');

if (isset($_POST['submit'])) {
    $fname = $_POST['fname'];
    $mnumber = $_POST['mobilenumber'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    // Server-side validation for mobile number and email
    if (strlen($mnumber) != 10 || !preg_match("/^[0-9]{10}$/", $mnumber)) {
        $_SESSION['msg'] = "Invalid mobile number. It should be 10 digits.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['msg'] = "Invalid email format.";
    } else {
        // Check if email already exists
        $sql = "SELECT * FROM tblusers WHERE EmailId=:email";
        $query = $dbh->prepare($sql);
        $query->bindParam(':email', $email, PDO::PARAM_STR);
        $query->execute();

        if ($query->rowCount() > 0) {
            $_SESSION['msg'] = "Email already registered.";
        } else {
            // Insert new user
            $sql = "INSERT INTO tblusers (FullName, MobileNumber, EmailId, Password) VALUES (:fname, :mnumber, :email, :password)";
            $query = $dbh->prepare($sql);
            $query->bindParam(':fname', $fname, PDO::PARAM_STR);
            $query->bindParam(':mnumber', $mnumber, PDO::PARAM_STR);
            $query->bindParam(':email', $email, PDO::PARAM_STR);
            $query->bindParam(':password', $password, PDO::PARAM_STR);
            $query->execute();
            $lastInsertId = $dbh->lastInsertId();

            if ($lastInsertId) {
                $_SESSION['msg'] = "You are successfully registered. Now you can login.";
                header('location:thankyou.php');
                exit;
            } else {
                $_SESSION['msg'] = "Something went wrong. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery-2.1.4.min.js"></script>
</head>
<body>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
            </div>
            <section>
                <div class="modal-body modal-spa">
                    <div class="login-grids">
                        <div class="login">
                            <div class="login-right">
                                <form name="signup" method="post" onsubmit="return validateForm()">
                                    <h3>Create your account</h3>
                                    <?php if(isset($_SESSION['msg'])) { ?>
                                        <div class="alert alert-info">
                                            <?php echo htmlentities($_SESSION['msg']); unset($_SESSION['msg']); ?>
                                        </div>
                                    <?php } ?>
                                    <input type="text" placeholder="Full Name" name="fname" autocomplete="off" required="">
                                    <input type="text" placeholder="Mobile number" name="mobilenumber" maxlength="10" autocomplete="off" required="">
                                    <input type="text" placeholder="Email id" name="email" id="email" onBlur="checkAvailability()" autocomplete="off" required="">
                                    <span id="user-availability-status" style="font-size:12px;"></span> 
                                    <input type="password" placeholder="Password" name="password" required="">	
                                    <input type="submit" name="submit" value="CREATE ACCOUNT">
                                </form>
                            </div>
                            <div class="clearfix"></div>								
                        </div>
                        <p>By logging in you agree to our <a href="page.php?type=terms">Terms and Conditions</a> and <a href="page.php?type=privacy">Privacy Policy</a></p>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<script>
function validateForm() {
    var mobile = document.forms["signup"]["mobilenumber"].value;
    var email = document.forms["signup"]["email"].value;
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

    if (mobile.length != 10 || !/^[0-9]{10}$/.test(mobile)) {
        alert("Mobile number must be 10 digits.");
        return false;
    }

    if (!emailPattern.test(email)) {
        alert("Invalid email address.");
        return false;
    }

    return true;
}

function checkAvailability() {
    $("#loaderIcon").show();
    jQuery.ajax({
        url: "check_availability.php",
        data: 'emailid='+$("#email").val(),
        type: "POST",
        success: function(data) {
            $("#user-availability-status").html(data);
            $("#loaderIcon").hide();
        },
        error: function (){}
    });
}
</script>

<script src="js/bootstrap.min.js"></script>
</body>
</html>
