<style>
/* Navbar background color */
.navbar-default {
    background-color: #667618;
    border-color: #5a6815;
}

/* Navbar text color */
.navbar-default .navbar-nav > li > a {
    color: #ffffff;
}

/* Navbar hover and focus states */
.navbar-default .navbar-nav > li > a:hover,
.navbar-default .navbar-nav > li > a:focus {
    color: #008000; /* Green text color on hover */
    background-color: #ffffff; /* White background on hover */
}

/* Active nav item */
.navbar-default .navbar-nav > .active > a,
.navbar-default .navbar-nav > .active > a:hover,
.navbar-default .navbar-nav > .active > a:focus {
    color: #008000; /* Green text color for active item */
    background-color: #ffffff; /* White background for active item */
}

/* Dropdown menu styles */
.navbar-default .navbar-nav > .open > a, 
.navbar-default .navbar-nav > .open > a:hover, 
.navbar-default .navbar-nav > .open > a:focus {
    background-color: #ffffff; /* White background for open dropdown */
    color: #008000; /* Green text color for open dropdown */
}

.dropdown-menu {
    background-color: #667618; /* Dropdown background color */
    border: 1px solid #5a6815;
}

.dropdown-menu > li > a {
    color: #ffffff; /* Dropdown text color */
}

.dropdown-menu > li > a:hover,
.dropdown-menu > li > a:focus {
    background-color: #ffffff; /* White background for dropdown hover */
    color: #008000; /* Green text color for dropdown hover */
}

/* Dropdown divider color */
.dropdown-menu .divider {
    background-color: #5a6815;
}

/* Mobile nav icon color */
.navbar-default .navbar-toggle .icon-bar {
    background-color: #ffffff;
}

.navbar-default .navbar-toggle:hover,
.navbar-default .navbar-toggle:focus {
    background-color: #ffffff;
}

.navbar-default .navbar-toggle:hover .icon-bar,
.navbar-default .navbar-toggle:focus .icon-bar {
    background-color: #667618;
}
</style>


<!--- header ---->
<!--- /header ---->

<!--- navbar ---->
<div class="navbar-wrapper">
    <div class="container">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="package-list.php">Tour Packages</a></li>
                        <li><a href="http://localhost/tms/tms/inde">Back Home</a></li>
                        <?php if(!isset($_SESSION['login'])) { ?>
                            <li><a href="enquiry.php">Enquiry</a></li>
                        <?php } ?>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php if(isset($_SESSION['login'])) { ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                    Welcome, <?php echo htmlentities($_SESSION['login']); ?> <span class="caret"></span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a href="profile.php">My Profile</a></li>
                                    <li><a href="change-password.php">Change Password</a></li>
                                    <li><a href="tour-history.php">My Tour History</a></li>
                                    <li><a href="issuetickets.php">Issue Tickets</a></li>
                                    <li role="separator" class="divider"></li>
                                    <li><a href="logout.php">Logout</a></li>
                                </ul>
                            </li>
                            <li><a href="#" data-toggle="modal" data-target="#myModal3">Need Help?</a></li>
                        <?php } else { ?>
                            <li><a href="http://localhost/tms/tms/admin/index.php">Admin</a></li>
                            <li><a href="#" data-toggle="modal" data-target="#myModal">Sign Up</a></li>
                            <li><a href="#" data-toggle="modal" data-target="#myModal4">Sign In</a></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</div>
<!--- /navbar ---->

<script>
document.addEventListener('DOMContentLoaded', function() {
    var dropdownToggle = document.querySelector('.dropdown-toggle');
    var dropdownMenu = document.querySelector('.dropdown-menu');
    
    if (dropdownToggle && dropdownMenu) {
        dropdownToggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            dropdownMenu.classList.toggle('show');
        });

        document.addEventListener('click', function(e) {
            if (!dropdownToggle.contains(e.target) && !dropdownMenu.contains(e.target)) {
                dropdownMenu.classList.remove('show');
            }
        });
    }
});
</script>

<style>
/* Add this to your existing CSS */
.dropdown-menu.show {
    display: block;
}
</style>