<?php
session_start();
if(isset($_POST['signin']))
{
$email=$_POST['email'];
$password=md5($_POST['password']);
$sql ="SELECT EmailId,Password FROM tblusers WHERE EmailId=:email and Password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
$_SESSION['login']=$_POST['email'];
echo "<script type='text/javascript'> document.location = 'package-list.php'; </script>";
} else{
	
	echo "<script>alert('Invalid Details');</script>";

}

}

?>
<style>
.modal-dialog {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
}

.modal-content {
    width: 100%;
    max-width: 400px; /* Adjust this value as needed */
    margin: auto;
    padding: 20px;
    text-align: center;
}

.login-right {
    width: 100%;
    float: none;
}

.login-right h3 {
    color: #4CB320;
    font-weight: normal;
    font-size: 20px;
    margin-bottom: 20px;
}

.login-right input[type="text"],
.login-right input[type="password"] {
    width: 100%;
    padding: 10px;
    font-weight: normal;
    background: none;
    border: 1px solid #E6E4E4;
    color: #333; /* Changed from #D2D1D1 for better visibility */
    outline: none;
    font-size: 14px;
    margin-top: 10px;
    box-sizing: border-box;
}

.login-right h4 {
    color: #48cfc1;
    font-size: 12px;
    margin: 15px 0;
}

.login-right h4 a {
    color: #4CB320;
    text-decoration: none;
}

.login-right h4 a:hover {
    color: #A9A8A8;
}

.login-right input[type="submit"] {
    background: #4CB320;
    color: #fff;
    font-size: 18px;
    border: none;
    width: 100%;
    outline: none;
    padding: 10px 15px;
    transition: 0.5s all;
    margin-top: 15px;
    cursor: pointer;
}

.login-right input[type="submit"]:hover {
    background: #3F84B1;
}

.login-grids p {
    margin-top: 15px;
    font-size: 12px;
}

.login-grids p a {
    color: #4CB320;
}
</style>

<div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content modal-info">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>						
						</div>
						<div class="modal-body modal-spa">
						<div class="logo">
              			  <img src="tms/tms/images/logo.png" alt="logo" width="150" height="auto" />
          				  </div>
                          </div>
							<div class="login-grids">
								<div class="login">
			<br>
									<div class="login-right">
										<form method="post">
											<h3>Sign in with your account </h3>
	<input type="text" name="email" id="email" placeholder="Enter your Email"  required="">	
	<input type="password" name="password" id="password" placeholder="Password" value="" required="">	
											<h4><a href="forgot-password.php">Forgot password</a></h4>
											
											<input type="submit" name="signin" value="SIGNIN">
										</form>
									</div>
									<div class="clearfix"></div>								
								</div>
								<p>By logging in you agree to our <a href="page.php?type=terms">Terms and Conditions</a> and <a href="page.php?type=privacy">Privacy Policy</a></p>
							</div>
						</div>
					</div>
				</div>
			</div>