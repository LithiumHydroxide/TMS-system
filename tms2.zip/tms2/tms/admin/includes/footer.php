<div class="copyrights">
	 <p>© HAKIM |  <a href="#">BBTT</a> </p>
</div>	
